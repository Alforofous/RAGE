Vector3d v(1,2,4);
cout << v.cwiseSqrt() << endl;
