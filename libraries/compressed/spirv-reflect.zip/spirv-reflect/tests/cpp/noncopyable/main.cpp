#include "spirv_reflect.h"

int main(int argc, char** argv) {
  spv_reflect::ShaderModule shaderModule;
  shaderModule = spv_reflect::ShaderModule();
  return 0;
}